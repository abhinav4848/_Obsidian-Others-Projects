---
URL: https://notes.andymatuschak.org/zRTw8KaPErhSCyC2NYGHyP7?stackedNotes=z7ffiDfqTR9pPcEEUUbCL7C
title: "Transfer learning"
---
# Transfer learning
See also [[Desirable difficulties, after Bjork]] 

For an active area of interest, see: [[Retrieval practice and transfer learning]] .
# Reference
1. Reder, L., & Klatzky, R. L. (1994). Transfer: Training for performance. In D. Druckman & R. A. Bjork (Eds.), Learning, Remembering, Believing: Enhancing Human Performance (pp. 25–56). National Academies Press. [https://doi.org/10.17226/2303](https://doi.org/10.17226/2303)

