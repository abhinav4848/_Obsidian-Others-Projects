---
URL: ["https://notes.andymatuschak.org/zN7KLBKWMTmFqthmFPVSNbP?stackedNotes=z984ZZLbG4wREM6HAZAovMB&stackedNotes=z179DabP631i5Mjf2DBMwoS", "https://notes.andymatuschak.org/z984ZZLbG4wREM6HAZAovMB"]
title: "Enacted experiences have incredible potential as a mass medium"
---
# Enacted experiences have incredible potential as a mass medium
I believe it’s possible to create an [[Enacted experience]] with the primary purpose of communicating ideas, values, and practices—akin to doing the “job” of a book. This is a powerful proposition because [[Enacted experiences can create intense personal connection to authored targets]] and [[Enacted experiences can bootstrap active participation in enabling environments]].

Avenues:
- Apprenticeships and other social institutions (e.g. YC) do this today, but those aren’t mass media forms ([[Enacted experiences are hard to distribute]])
- Video games are a mass medium, but they’re used almost exclusively to convey aesthetic experiences, not as part of an enabling environment
- Meditation apps are a promising reference: [[Guided meditation apps deliver enacted experiences in a mass medium]]

I see this as one of the core ideas of [The Primer++](https://notes.andymatuschak.org/zWxp9Cw9Nc7ixAGAaXwqq3H).

There seems to be some essential tension here with [Interaction is a cost center in interface design](https://notes.andymatuschak.org/z179DabP631i5Mjf2DBMwoS).
