---
URL: https://notes.andymatuschak.org/z9TuEpnqEtLdy2TWWVicLsU
title: "Inappropriate time pressures often harm creative work"
---
# Inappropriate time pressures often harm creative work
 [[Constraints often breed creativity]], but not when the nature of the constraint is simply incompatible with the work at hand. For instance, when you’re not what direction to head next in a design, “Crazy Eights” can help: fold a piece of paper into eight parts, then spend one minute sketching an idea into each part. Great! If you’ve got momentum on a project, setting a timeline can help you make better trade-offs, satisfice into “done”, and sometimes even focus. But if you’re trying to finish up a major creative project before some deadline, and you find yourself in a state that’s incompatible with the deadline, then that time pressure isn’t going to provide helpful focus: it’s going to make you feel like a failure ([[Scarcity mindset]]) and make the work even worse.

This is a special case of  [[Process over product]]. Also related: . [[Deep research requires a slower pace than tech industry work]]

## Stats book story
Here’s a concrete story from my experience. I was in the middle of producing a big demo video of a new design. I’d previously set myself the goal of finishing the video by the end of the month. At the start of the week, I sketched out what I’d need to do to make that happen. It looked just barely possible, but everything needed to go perfectly all week to make it happen.

On Tuesday morning of that final week, I ran aground on a stats textbook I was trying to adapt for the video. The sections I’d previously prepared wouldn’t work with the script after all; I needed to use a later chapter. So I flipped to the later chapter and started looking for a passage I could adapt. This is where the trouble started. Because I was in a hurry, I wasn’t really _reading_ the textbook; I was just pattern matching for something that would solve my problem. I didn’t give myself enough time to really understand what was being said, so nothing seemed to match. I’d get harried and flip to the next section, which I’d understand even less well. But I didn’t really understand that this was what was happening—I thought I just needed to keep searching for the right spot. After somehow burning 90 minutes of flailing without any real progress, I finally realized that I needed to stop and actually read the textbook. I did that, and after 30 minutes I had what I needed.

So the initial moral of the story is something like: OK, slow down, use the correct approach, or else you’ll waste even more time flailing. But the more important moral, I think, is that I was stressed and unhappy during that whole period—including when I finally did stop to read carefully! That’s because I was still operating under the mindset of trying to finish everything before a super tight deadline. My Timekeeper ruled my emotional world. In this mindset, every setback becomes a threat—a problem to be solved, not an impetus to [[Get curious]]. And it’s very hard to [[Get playful]]. Not only is this unpleasant, but it’s not a regime where I’ll do the kind of work I want to.

At mid-day I took a walk, and I was still feeling tense about the morning work block. Then I laughed at myself as I suddenly realized that my unhappy experience was utterly self-inflicted, and utterly unnecessary. I said to myself “you know, it’s okay to publish this demo _next_ week—that’s clearly what’s going to happen anyway, whether you like it or not”, and all the tension immediately dropped away. [[Sense of abundance]]. Funnier yet: objectively speaking, if I look at my output on days when I’m not holding myself to strong time pressure, I still get roughly as much done! A little less, yes; and sometimes I fall into rabbit holes I’d have avoided with a clear deadline. But I’m much more likely to trip on important insights on those days without time pressure. And insight density, not output density, is the most important metric for my work.

Q. Recall the parable of trying to adapt the stats textbook under a tight deadline. What did you realize on your afternoon walk?  
A. … (see note if necessary)

Vaguely related: [[Momentum as explore-exploit heuristic in creative work]]
