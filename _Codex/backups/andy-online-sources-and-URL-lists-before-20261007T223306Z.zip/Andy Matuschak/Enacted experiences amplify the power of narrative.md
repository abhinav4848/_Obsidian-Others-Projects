---
URL: "https://notes.andymatuschak.org/zQ9BWTY2JK6eJvCSqupc7UF"
title: "Enacted experiences amplify the power of narrative"
---
# Enacted experiences amplify the power of narrative
Narrative is a powerful tool both because it creates emotional involvement and because it can support understanding ([[Narrative as cognitive scaffolding]]). Narrative can be made even more powerful by making it an [[Enacted experience]], because [[Enacted experiences can create intense personal connection to authored targets]].

In Portal and Bioshock, for instance, a memorable narrative is woven into the sequence of environments, character appearances, and available interactions. Unlike games like Final Fantasy, in which the story is largely separated from gameplay and presented more like a film, Portal’s and Bioshock’s narratives feel like they emerge as a consequence of player action.

# References
1.