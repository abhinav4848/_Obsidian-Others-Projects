---
title: "Spaced repetition can lower the stakes around destructive inbox-maintenance operations"
---
# Spaced repetition can lower the stakes around destructive inbox-maintenance operations
[[Inboxes only work if you trust how they’re drained]], but [[Triage strategies for maintaining inboxes (e.g. Inbox Zero) are often too brittle]]. In large part that’s because [[Software interfaces often harmfully frame destructive operations as final decisions, not contingent preferences]].

If you recast the destructive operations as “not right now,” they feel completely different. That browser tab isn’t gone—it’ll come back later. Maybe it’s a day later at first, then if I skip it again, a few days later, then maybe a week, and so on, until “not right now” is effectively “close”… but it doesn’t feel nearly so stressful. This notion can be applied to task queues, reading lists ([[A reading inbox to capture possibly-useful references]]), email inboxes, etc. [[Spaced repetition mechanics create a sense of effortlessness]].

It helps me to bring some physicality into the metaphor. Imagine your desk has lots of papers on it. You naturally pull out the few which you’re using at the moment, and maybe you set a few aside for special attention. The rest sit, perhaps in a couple of piles. You intermittently look through the piles, pulling out ones which strike your fancy. The ones which sit long enough start to simply dissolve, compost into the table surface. You can always restore them if you like, but if you don’t, they’ll get tilled under.

This is an example of a way in which [[Andy Matuschak/Spaced repetition systems can be used to program attention|Spaced repetition systems can be used to program attention]].