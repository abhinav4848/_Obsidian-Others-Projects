---
title: "Spaced repetition prompt design is about designing tasks for your future self"
---
# Spaced repetition prompt design is about designing tasks for your future self
[[Writing good spaced repetition memory prompts is hard]], but here’s one useful mental model. When you make a prompt for a [[Andy Matuschak/Spaced Repetition memory system|Spaced repetition memory system]], you are _giving your future self a recurring task_. Prompt design is task design.

So if you’re writing prompts to help learn a particular idea, you must design tasks which reinforce your understanding of that idea when you perform them. If you’re writing prompts to support creative work, you must design tasks which cause you to notice possibilities or connections, and so on.

## “Capturing” an idea with spaced repetition prompts is like translation
The process feels surprisingly similar to translating text between languages. When translating a passage, you’re searching for words which, when read, light up a similar set of bulbs in readers’ minds to those which might have been activated by the original language. It’s not a rote operation. If the passage involves allusion, metaphor, or humor, you won’t translate literally; you’ll try to find words which recreate the experience of reading the original for a member of a foreign culture.

When writing SRS prompts to help you internalize an idea, you’re performing something similar to language translation: which tasks, when performed, require lighting the bulbs which are activated when you have that idea “fully loaded” into your mind?

---

How do we go about designing such a task? If the idea is fairly simple, it may be possible to directly conceive a task which reliably lights all those bulbs. But when the idea has too many important facets, it’s hard to design a task which reliably stimulates all those elements. So it’s best to break concepts down into their simplest units: [[Andy Matuschak/Spaced repetition memory prompts should usually focus on one atomic unit|Spaced repetition memory prompts should usually focus on one atomic unit]].