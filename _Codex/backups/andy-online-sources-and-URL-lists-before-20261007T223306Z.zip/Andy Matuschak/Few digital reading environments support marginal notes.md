---
URL: https://notes.andymatuschak.org/z4aipv9wyMg4qZGANaVjkrJ?stackedNotes=zX95uZHiGWNiNTDF3wETWtq&stackedNotes=zGsRWkonFv1KGAsWwiYA3he
title: "Few digital reading environments support marginal notes"
---
# Few digital reading environments support marginal notes
When reading a physical book, the natural thing to do is to scribble in the margins, next to the relevant passages. Or maybe to attach a sticky note at the relevant spot. But for whatever reason, digital reading environments almost never support this kind of interaction. Annotations are hidden away under some icon of a sticky note, or in a “notebook” which displays them in a flat list, de-spatialized and disconnected from the content.

[LiquidText](https://notes.andymatuschak.org/zN9pG99Y6GY8f6YjUTiKi5Z) and MarginNote are the only exceptions which come to mind. Note that neither supports EPUB! [[All desktop EPUB readers are awful]] More recently, [[Readwise]] Reader has added marginal notes. And they support EPUB—a rarity. Unfortunately, the PDF support is quite clunky.

Google Docs has already pinned down a more-or-less fine UX here; I do wish others would simply copy it.

[Hypothes.is](https://notes.andymatuschak.org/z53bJfaxPoRbHsVeKQMx8kn) offers a halfway solution, providing some spatialized indexes by way of edge marks in the gutter of its sidebar. But the annotations themselves are presented in a flat list; the edge marks just apply a filter. You still can’t scroll through a document and read the annotations alongside it, as [Ted Nelson](https://notes.andymatuschak.org/zSYx6qqLStC6TVg4uDDNXAf) (no note) had depicted in 1972 (!).

Note that the location doesn’t need to be that physically precise. It’s just in the general vicinity. [[Digital annotation is too formal]].

[Romat, H., Pietriga, E., Riche, N. H., Hinckley, K., & Appert, C. (2019, October 1). SpaceInk: Making Space for In-Context Annotations. UIST 2019 32nd ACM User Interface Software and Technology Symposium](https://notes.andymatuschak.org/z6b8dLPVoC57KBQWKCY2Dgq) has a nice interaction for making space for annotations.

Amazon’s introduced “Active Canvas” for their Kindle Scribe in 2024, which implies a simplified SpaceInk-like interaction. EPUBs only. [Kindle Scribe 1 to get Active Canvas and Extended Margins in 2025](https://goodereader.com/blog/kindle/kindle-scribe-1-to-get-active-canvas-and-extended-margins-in-2025)
