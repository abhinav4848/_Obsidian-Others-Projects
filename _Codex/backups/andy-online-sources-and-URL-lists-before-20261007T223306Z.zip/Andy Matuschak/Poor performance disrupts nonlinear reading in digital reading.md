---
URL: https://notes.andymatuschak.org/zBeBbzwU8LAyi2D5jqBJpS?stackedNotes=zJ4k4feCLspoCid7C4mzmvL&stackedNotes=zVx3t4nDyk9tyuWQiBzsSDT
title: "Poor performance disrupts nonlinear reading in digital reading"
---
# Poor performance disrupts nonlinear reading in digital reading
[[Skillful reading is often non-linear]], but digital reading experiences often make rapid scanning and referencing more painful simply by being slow. When flipping a few pages forwards or backwards occasions hiccups or blank screens, the environment pushes readers to read less effectively.

Worse: because [[Maintaining multiple reading positions is difficult when reading digitally]], one must often perform many back-to-back “flip page” operations to move between relevant passages. If you were reading a physical book, you’d stick your finger in one position and turn the intervening pages as a block, but the digital reader must suffer delays which usually accumulate with each turned page.
