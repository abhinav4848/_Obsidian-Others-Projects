---
URL: https://notes.andymatuschak.org/zQvbnYfHdG1gARTbtC4pje6?stackedNotes=zojJRcfGstU2Ss6JRMzd15&stackedNotes=zS27HJzP3uD366crN7PYDQU
title: "Prefer fine-grained associations"
---
# Prefer fine-grained associations
Links between materials in an information system (e.g. [[Evergreen notes should be densely linked]]) can be fine-grained (like a citation in the middle of a sentence of a paper) or coarse-grained (like a “see also” section).

It’s generally better to make fine-grained associations. For instance, rather than evaluating a jumbled list of papers related to the paper you’re reading, it’s more helpful to see that I noticed paper X relates to paragraph N.

This is particularly true when links are bidirectional, since you’ll need help to see why the “backwards” relationship makes sense.
