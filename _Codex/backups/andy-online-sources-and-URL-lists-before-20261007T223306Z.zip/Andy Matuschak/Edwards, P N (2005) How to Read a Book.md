---
URL: "https://notes.andymatuschak.org/zF3idWHy3CyBA7foes3nagx"
title: "Edwards, P N (2005) How to Read a Book"
---
# Edwards, P N (2005) How to Read a Book
# Edwards, P. N. (2005). How to Read a Book.
Not to be confused with [[How to Read a Book - Adler and van Doren]]

General advice on how to read non-fiction effectively. Comments related to [[Write about what you read to internalize texts deeply]]; [[Skilful reading is often non-linear]]; [[The best way to read is highly contextual]].

The author’s focus is on efficient and effective reading. You should be able to read a 300 page book in 6-8 hours, understand the key points, and perform some initial analysis, though you won’t necessarily have internalized all the details.

He suggests three passes over the book’s content: {overview, focused on getting a general picture, marking important passages, generating questions} ({10%} time); {detailed, for a careful, critical grasp} ({60%} time); {notes, to support recall and synthesis} ({30%} time).

To understand a book’s intellectual context, he suggests to determine what, and who, {it is *answering*}.

Q. About how many pages of notes per 100 pages of text does Paul Edwards suggest to shoot for?
A. 3-5 pages.

Q. What key personal limit does Paul Edwards suggest readers must confront when embarking on reading a book?
A. How much time they will spend.

Q. What parts of chapters / major sections does Paul Edwards suggest readers should focus on (hourglass structure)?
A. Beginnings and ends, which tend to focus on broader information.

Q. If reading a book will take three hours, how does Paul Edwards suggest scheduling that time?
A. As three one-hours sessions.

# Reference
1.