---
URL: https://notes.andymatuschak.org/z2q7U5ZvXeDxXD6vXAbZb9a?stackedNotes=zWzVw2VM4TPjpKXnHUfLaso&stackedNotes=zMmH3GBLKotdP4t1sdSvEQJ
title: "Culturally default behaviors fill spare time with others’ ideas"
---
# Culturally default behaviors fill spare time with others’ ideas
Nature abhors a vacuum; contemporary culture abhors a silence. If I find myself with a spare moment, the culturally “default” thing to do seems to be to fill it—with reading or listening (books, articles, podcasts), with a friendly conversation, with an execution-oriented task. These activities may be restful and enjoyable, of course, but they often combine so that days or weeks may easily pass without a contiguous hour spent in deep thought about one’s own ideas. There’s always plenty more in the (reading, email, browser tab, to-do list) inbox.

Some meeting software has meters which display how much each participant is speaking—how much “airtime” each consumes. You can imagine extending that same concept to thoughts and mental speech. Insight requires inputs, of course, so you wouldn’t want to cloister yourself away indefinitely. But how can you step far from well-trodden creative paths if others’ voices consistently consume much more mental “airtime” than your own? [[It’s hard to hear yourself think]].

It’s odd that this seems to be the default situation, even in nominally creative knowledge work roles. See also: [[Displacement activity]], [[People prefer doing to thinking]].

One useful antidote: [[Get bored]].

---

Andy matuschak wrote a short blog post about this in 2010, though he didn’t understand it very well then: [Square Signals : An Anesthetic Default](https://blog.andymatuschak.org/post/1042904867/an-anesthetic-default)

[Deresiewicz, W. (2010, March 1). Solitude and Leadership. The American Scholar.](https://notes.andymatuschak.org/zY2sfBpNp2NZKiA3d1CCRPX):

> Here’s the other problem with Facebook and Twitter and even The New York Times. When you expose yourself to those things, especially in the constant way that people do now—older people as well as younger people—you are continuously bombarding yourself with a stream of other people’s thoughts. You are marinating yourself in the conventional wisdom. In other people’s reality: for others, not for yourself. You are creating a cacophony in which it is impossible to hear your own voice, whether it’s yourself you’re thinking about or anything else. That’s what Emerson meant when he said that “he who should inspire and lead his race must be defended from travelling with the souls of other men, from living, breathing, reading, and writing in the daily, time-worn yoke of their opinions.”
