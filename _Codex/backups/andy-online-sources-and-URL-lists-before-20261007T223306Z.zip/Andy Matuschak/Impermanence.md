---
title: "Impermanence"
---
# Impermanence
One of the [[Three characteristics of existence]] central to Buddhism. All experiences, perceptions, and forms arise and pass away; they are always in flux. This is true from the smallest sensation or concept to one’s existence itself.

The Buddhist claim is specifically that all *sankhara* are impermanent. That word’s meaning is subtle, and I don’t think I understand it well. Simple translations include “formations” and “conditioned things.” It’s meant to represent a fused “subject-object” epistemological thing. I think this means that Buddhism makes no claim that, say, the Platonic number 3 is impermanent: that’s just an object. But our thoughts, claims, and activities with respect to 3 are impermanent.

The Pali word for this is {anicca}.

# References
1.