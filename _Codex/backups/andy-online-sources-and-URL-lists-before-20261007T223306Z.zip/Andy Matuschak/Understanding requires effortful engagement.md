---
URL: "https://notes.andymatuschak.org/z8ccRLda8BqJafNxjQBpzis"
title: "Understanding requires effortful engagement"
---
# Understanding requires effortful engagement
If you want to really understand an idea, you have to grapple with it.

You can’t just read something, listen to a lecture, or hear a notion in a conversation. You’ve got to wonder: where does this apply and where does it not? What are the implications? What are the assumptions? Whose view is represented here? What does this refute? etc.

As Stephen Kosslyn notably says,
> The first maxim is “Think it through.” The key idea is very simple: the more you think something through, paying attention to what you are doing, the more likely you are to remember it.

From a [[Cognitive psychology]] perspective, a common explanation is that this kind of engagement is necessary to 
1. infer propositions which aren’t explicitly stated or demonstrated; and
2. to connect new observations with prior knowledge. (see e.g. [[Comprehension - Kintsch]] 
This notion is a core idea of [[Constructivism]], and it’s why naive transmissionism doesn’t work.

And Schopenhauer:
> When we read, another person thinks for us: we merely repeat his mental process. … For the more one reads the fewer are the traces left of what one has read; the mind is like a tablet that has been written over and over. Hence it is impossible to reflect; and it is only by reflection that one can assimilate what one has read if one reads straight ahead without pondering over it later, what has been read does not take root, but is for the most part lost. Indeed, it is the same with mental as with bodily food: scarcely the fifth part of what a man takes is assimilated; the remainder passes off in evaporation, respiration, and the like.

[[Grant Sanderson]] (2019-11-28):
> You need to make eye contact with the idea.

---
# Reference
1. Kosslyn, S. M. (2017). The Science of Learning: Mechanisms and Principles. In S. M. Kosslyn & B. Nelson (Eds.), *Building the Intentional University: Minerva and the Future of Higher Education* (1 edition, pp. 149–164). Cambridge, MA: The MIT Press.
2. Schopenhauer, A. (2015). On reading and books. In C. Janaway (Ed.), & A. Del Caro (Trans.), *Parerga and Paralipomena: Short Philosophical Essays* (Vol. 2). [https://doi.org/10.1017/CBO9781139016889](https://doi.org/10.1017/CBO9781139016889) (Original work published 1851)
