---
URL: https://notes.andymatuschak.org/zVdb1Ku6fzVAFP5A6BhBbWR?stackedNotes=zLCdZ9xcHzjks8vgoGkycSr
title: "Inquiry-based learning"
---
# Inquiry-based learning
See e.g. [[Moore method]] 

More generally: [[Constructivism]]
# Related
- [[Educational environments usually don’t involve original thought]]
- [[Internally-modulated learning is self-actualizing; externally-modulated learning is self-abnegating]]
- [The Young Lady’s Illustrated Primer](https://notes.andymatuschak.org/zCjT6omFavtr7Zx2S5do6qC) (Not worth making articles on).
