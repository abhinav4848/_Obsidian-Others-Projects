---
URL: https://notes.andymatuschak.org/zSKD44o2VTbQuQYqmjupo4B?stackedNotes=zDGk8tvVDD1mbTgpMMB5UGh
---
# Release valves for non-linear thought may support improved linear output
One way to navigate the paradox inherent in [[Prefer linear work products but non-linear working environments]]: by making non-linear structures available for work-in-progress, you create a release valve for tangential thought—which in turn can free the author to focus on their “primary” line of thinking.

For instance, on a whiteboard or in a notebook, if you’re developing a “main” bulleted list or diagram and something occurs to you that doesn’t quite fit in, you can simply write it off to the side and perhaps drawn an arrow.

Likewise, in a Hypertext Note-writing system, tangential thoughts can always be captured in another note and linked in: [[Evergreen notes lower the emotional stakes in editing manuscripts]]. But this benefit isn’t necessarily about building up a well-connected ontology (as described in [[Evergreen notes should be densely linked]]); it’s more about maintaining hygiene and attention.

Linear authoring environments like word processors force the author to create bubbles of non-linearity inside their linear work, e.g. by making appendices or colored “stray notes” sections or using Google Comments. These approaches all feel strained and unnatural: [Tyranny of formality in interfaces](https://notes.andymatuschak.org/zPVYHEJdDBoMoQV5pQ4h71S)

Per Ted Nelson ([source](https://www.youtube.com/watch?v=En_2T7KH6RA), [via Mark Knight](https://twitter.com/mjknght/status/1309769444592431113)):

> …the ideas were constantly trying to escape. What is a parenthesis but an idea trying to escape? What is a footnote but an idea that tried — that jumped off the cliff?

---

Q. In what sense does the treatment of tangential thought in non-linear working environments act like a release valve?  
A. Stray thoughts can be usefully captured and related for later attention without interfering with one’s primary focus.

Q. How does the “release value” theory of non-linear writing subvert the usual narrative around hypertext note systems?  
A. Maybe the value of non-linear writing isn’t in the future value of the embedded links, but rather that capturing tangential thoughts can help authors focus on their “primary” line of thinking while writing.

# References
Original observation from Nick Barr, 2020-09-25
