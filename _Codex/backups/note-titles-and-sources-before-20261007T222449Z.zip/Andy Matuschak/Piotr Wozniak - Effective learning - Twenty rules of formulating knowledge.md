---
URL: https://notes.andymatuschak.org/z7nmQ12agpmDmFoonENsQQN
---
# Piotr Wozniak - Effective learning - Twenty rules of formulating knowledge
[https://www.supermemo.com/en/archives1990-2015/articles/20rules](https://www.supermemo.com/en/archives1990-2015/articles/20rules)

By [[Piotr Wozniak]]

First text I know addressing the topic of how to write effective spaced repetition prompts.
- [[Learn before you memorize]]

## References
- Source for this file: [Original article](https://notes.andymatuschak.org/z96Xr88dMaAGrn3CobJnMUD)
