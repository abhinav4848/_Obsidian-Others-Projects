---
URL: https://notes.andymatuschak.org/z3QWwvfYS5exfZE53dKwt7r?stackedNotes=zK3Qi3FKpVtNp5Ss47d8136
---
In many fields, experts become experts mostly by developing more sophisticated mental representations ([[Andy Matuschak/Mental representations, after Ericsson and Pool|Mental representations, after Ericsson and Pool]]), which amounts to increasing the size of their mental chunks ([[Chunks in human cognition]]). This increases their information processing capacity ([[Human channel capacity increases with bits-per-chunk]], [[Recoding can increase chunk size]]). This happens through practice: [[Good practice encodes more effective chunk recoding schemes]]

> What sets expert performers apart from everyone else is the quality and quantity of their mental representations.

(Ericsson and Pool, 2016, p. 62, not well-cited)

For example, the model developed by Simon and Gilmartin (1973) suggests that chess masters have encoded order tens of thousands of chunks. (See also [[Andy Matuschak/Chase and Simon - Perception in chess|Chase and Simon - Perception in chess]])

[Knowledge work often requires solving search problems](https://notes.andymatuschak.org/z2t9jQbyU3uDb5crGY29C5z). Ericsson and Pool suggest that expert search performance comes from more complex chunk schemas (2016, p. 70-72). The argument’s not made very strongly, but because [[Andy Matuschak/Human channel capacity increases with bits-per-chunk|Human channel capacity increases with bits-per-chunk]], this would seem to explain superior culling and feedback-uptake performance.

---

## References
Simon, H. A., & Gilmartin, K. (1973). A simulation of memory for chess positions. Cognitive Psychology, 5(1), 29–46. [https://doi.org/10.1016/0010-0285(73)90024-8](https://doi.org/10.1016/0010-0285\(73\)90024-8)

Ericsson, A., & Pool, R. (2016). _Peak: Secrets from the New Science of Expertise_ (1 edition). Eamon Dolan/Houghton Mifflin Harcourt. [Peak - Ericsson and Pool](https://notes.andymatuschak.org/zEwJDpZiu1YQoXYznxioznL)
