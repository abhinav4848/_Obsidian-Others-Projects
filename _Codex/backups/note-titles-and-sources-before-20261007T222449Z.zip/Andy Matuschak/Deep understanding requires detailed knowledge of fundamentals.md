# Deep understanding requires detailed knowledge of fundamentals
Type of Link: 📝 Article
Author: Andy Matuschak
Completion Status: To Start
Last edited time: January 18, 2024 7:55 PM

## References
- Source for this file: [Original article](https://notes.andymatuschak.org/zDxwRLcf5pn3crwNN2EqSYM)
