---
URL: https://notes.andymatuschak.org/zMbCwoVdjsqPNyTRRr3phPN
---
# Knowledge work rarely involves deliberate practice
[[Athletes and musicians pursue virtuosity in fundamental skills much more rigorously than knowledge workers do]]. One likely reason is that athletes/musicians engage in [Deliberate practice, after Ericsson](https://notes.andymatuschak.org/Deliberate_practice%2C_after_Ericsson) *(dead link)* —that is, activities focused specifically on improving skills.

Sure, knowledge workers regularly take on “growth opportunities,” like a new job that will push them beyond their prior skill sets. But their day-to-day activities are focused on _doing the job,_ not (usually) on building whatever skills are deficient. This is akin to a soccer player only playing games as a way to get in shape, rather than lifting weights and running drills. [[Typical work and performance environments don’t constitute deliberate practice]].

Ericsson claims (2016, p. 98) that there is no deliberate practice possible for knowledge work because there are no objective criteria (so, poor feedback), because the skills aren’t clearly defined, and because techniques for focused skill improvement in these domains aren’t known. I’m skeptical of the finality of these claims, in the face of e.g. [[Evergreen note-writing as fundamental unit of knowledge work]], [[Spaced repetition memory systems make memory a choice]], etc. But it’s true that at least for the moment, there’s nothing as straightforward as weightlifting that you can do to improve your communication skills.

There’s significant tension between this line of reasoning and [[Enabling environments focus on doing what’s enabled]] /  [[Enabling environments focus on creating opportunities for growth and action, not on skill-building]]. Those articles would seem to claim that top-notch tennis / piano academies are not enabling environments… which is almost certainly false. There’s potential tension also with [[Andy Matuschak/How might we situate tools for thought within intrinsically meaningful contexts|How might we situate tools for thought within intrinsically meaningful contexts?]]

See also [§Taking knowledge work seriously (Stripe convergence talk, 2019-12-12)](https://notes.andymatuschak.org/zBmSSpM1WfFDehxNCBcqSZp). #todo

---
# References
2. Ericsson, A., & Pool, R. (2016). _Peak: Secrets from the New Science of Expertise_ (1 edition). Eamon Dolan/Houghton Mifflin Harcourt. [Peak - Ericsson and Pool](https://notes.andymatuschak.org/zEwJDpZiu1YQoXYznxioznL)
3. [Nielsen, M. A. (2004). Principles of effective research (Technical Note No. 0404). The University of Queensland.](https://notes.andymatuschak.org/zKfPfesQJTAsZw5CATEpPzr)
> 	Many people don’t spend enough time on self-development. If you stop your development at the level which resulted in your first paper, it’s unlikely you’ll solve any major problems. More realistically, for many people self-development is an incidental thing, something that happens while they’re on the treadmill of trying to solve problems, generate papers, and so on, or while teaching. While such people will develop, it’s unlikely that doing so in such an ad hoc way will let them address the most important problems.