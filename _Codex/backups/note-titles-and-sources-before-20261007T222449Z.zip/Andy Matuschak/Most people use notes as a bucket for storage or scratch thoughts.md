---
URL: https://notes.andymatuschak.org/zKGjQtsTKgscAoq271ZzKqw?stackedNotes=zNQV445UEcyLXVsRVgoVSfv&stackedNotes=zR6RRbCfY5rFkiimFnaJZKB
---
# Most people use notes as a bucket for storage or scratch thoughts
People don’t want to forget an idea or a conversation or a task or quote from a book, so they write it down in Evernote or something. What’s the purpose? Probably: “To make sure I don’t forget." Maybe: “Just writing it down helps me remember.” 

In this conception, notes are a way to [[Close open loops]], not to accumulate insight. The “real” work happens outside the notes; the notes are just a reference system which stores information which might help, or a write-once pile of “messy” thoughts (Khoe). 

These are not [[Andy Matuschak/Evergreen Notes|Evergreen Notes]]. Most “storage-oriented” notes will never be useful again ([[Most people take only transient notes]]). More importantly, this framing misses that it’s possible for note-writing to be the “real” work ([[Evergreen note-writing as fundamental unit of knowledge work]]).

# Reference
2. Khoe, M.-L. (2016, December 21). [[Messy thought, neat thought]]. Retrieved September 17, 2019, from Khan Academy Early Product Development website: [https://klr.tumblr.com/post/154784481858/messy-thought-neat-thought](https://klr.tumblr.com/post/154784481858/messy-thought-neat-thought)