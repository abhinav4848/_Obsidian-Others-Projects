---
URL: https://notes.andymatuschak.org/zWSH2QNUsrTGP4V15JBaaEv?stackedNotes=zRWEWHx4cQyqQWRh26gp7ad&stackedNotes=zU3Cw3dParuur9TFVNJMiqS
---
# Participatory environments support learning
[[Understanding requires effortful engagement]]. One way to support that effort is to create a [[Participatory environment]] whose activities naturally produce that kind of effortful engagement. For example, an art camp might involve lots of painting and drawing activities which would create effortful engagement with color theory.

By contrast, non-participatory environments like books are often engaged passively. Most readers won’t engage effortfully, so they won’t make meaning.

# References
2. Matuschak, A. (2019). Why books don’t work. Retrieved from [https://andymatuschak.org/books](https://andymatuschak.org/books)