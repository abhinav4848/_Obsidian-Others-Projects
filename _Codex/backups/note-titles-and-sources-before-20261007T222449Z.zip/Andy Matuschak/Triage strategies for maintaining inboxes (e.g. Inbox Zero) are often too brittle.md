---
URL: https://notes.andymatuschak.org/zQvwwb95vzcHcpow3GWy5Wi?stackedNotes=zJ5Yzvba2729XKXivBBZ91J&stackedNotes=z2Pg1CbUyvjV4jEoqmr8Xua
---
# Triage strategies for maintaining inboxes (e.g. Inbox Zero) are often too brittle
[[Inboxes only work if you trust how they’re drained]], and [Inbox Zero](http://www.43folders.com/izero) is one approach to ensure that they do. It lowers items’ wait times (theoretically to one day) by aggressively increasing the departure rate.

In _Getting Things Done_, David Allen suggests that you can increase your queue's departure rate by strategically deferring, delegating, or dropping tasks. “Inbox Zero” is an elaboration by Merlin Mann. It ensures that you're increasing the departure rate _enough_ by processing your entire inbox down to zero items each day. This is a blunt approach, but it does ensure that the departure rate always exceeds the arrival rate.

## Challenges
You have to make a decision about every item in your inbox. This is a significant cost, and it’ll only make sense to pay when inboxes are relatively small.

Explicitly deferring a task imposes an emotional cost, possibly unnecessarily: “inbox zero” is only necessary if the arrival rate _always_ exceeds the departure rate. If the arrival rate is variable and sometimes sits below the departure rate, you can still handle everything in a reasonable timeframe.

Explicitly dropping a task is hard because [[Software interfaces often harmfully frame destructive operations as final decisions, not contingent preferences]].

More practically speaking, Inbox Zero usually leads to deferral numbness: it’s too easy to punt a task over and over again. Allen suggests that one should periodically perform a reflective review to reconsider tasks which are repeatedly deferred, but these reviews require yet more decisions. Adherence seems to be low.

When processing the inbox in this way, there’s also a lot of pressure to simply _do_ more of these tasks, which may not be what you actually want.

## Opportunities
A more ideal mechanism would ensure that wait times remain tolerable, but the cycle time doesn’t necessarily have to be one day. We must also consider the number of decisions to be made. I’d rather make fewer decisions but tolerate a longer average wait time.

One possible instantiation: [[Spaced repetition can lower the stakes around destructive inbox-maintenance operations]].
