# Voice-based interface
e.g. Siri, Alexa, etc; as instantiated in dedicated devices, e.g. AirPods, HomePod, etc.

See also:
- [[Silent speech interface]]
- [Specifying book passages with a few spoken words](https://notes.andymatuschak.org/zJxuTHe8PCELxMWhvzVxT8t) 

Q. [Taylor Rogalski](https://notes.andymatuschak.org/Taylor_Rogalski)’s observation on design difficulties with voice-based interfaces?  
A. They have no affordances!

## References
- Source for this file: [Original article](https://notes.andymatuschak.org/zWG9EgWoprv9cbXXkhg8YNS)
