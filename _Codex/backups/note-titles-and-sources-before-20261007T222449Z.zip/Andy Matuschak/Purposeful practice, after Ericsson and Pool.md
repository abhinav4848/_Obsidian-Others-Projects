---
URL: https://notes.andymatuschak.org/z9uHnUB5sQeGcEmmmqEGqBV
---
Purposeful practice, as defined by Ericsson and Pool (2016, p. 14-22), is driven by {specific}, {proximate} goals, with difficulty set to {just outside your comfort zone ([[Skill development requires challenging homeostasis]])}. To orchestrate this type of practice, you’ll need {good feedback}, which in turn usually requires {a coach}.

This type of practice is generally more characteristic of what produces experts; compare to [[Naive approaches to practice rapidly plateau]]. But, according to them, it’s not as powerful as [[Andy Matuschak/Deliberate practice|Deliberate practice]], a kind of purposeful practice which benefits from highly-developed training methods specifically designed to enhance performance.

Because you’re always pushing yourself in this type of practice, success requires intense focus. You’ll also have to contend with the problems described in [[Performance plateaus often require a change in approach to surmount]].

One possibly mechanism of action: [[Good practice encodes more effective chunk recoding schemes]]. 

---
## References
Ericsson, A., & Pool, R. (2016). _Peak: Secrets from the New Science of Expertise_ (1 edition). Eamon Dolan/Houghton Mifflin Harcourt. [Peak - Ericsson and Pool](https://notes.andymatuschak.org/zEwJDpZiu1YQoXYznxioznL)
