The original digital [[Spaced Repetition memory system]], created by [[Piotr Wozniak]]. Includes support for various related personal information management systems, such as [[Incremental reading]].

## References
- Source for this file: [Original article](https://notes.andymatuschak.org/z2oUypiCEtPaDqNjbUsawCj)
