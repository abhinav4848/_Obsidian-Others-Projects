---
aliases:
  - Cloze deletion prompts seem to produce less understanding than question/answer pairs in spaced repetition memory systems
URL: https://notes.andymatuschak.org/zX95uZHiGWNiNTDF3wETWtq?stackedNotes=zAt1K9ARQYguinoHH8cfaqQ&stackedNotes=Cloze_deletion_prompts_seem_to_produce_less_understanding_than_question%2Fanswer_pairs_in_spaced_repetition_memory_systems
---
# Cloze deletion prompts seem to produce less understanding than question-answer pairs in spaced repetition memory systems
It’s much easier to write [[Cloze deletion]] prompts: you can just copy/paste some source text and delete some phrase. But I find that prompts created this way tend to result in shallower understanding. After several repetitions, I’ll remember the answer, but it often feels like I’m pattern matching ([[Spaced repetition memory prompts should be written to discourage shallow “pattern matching”]]) rather than deeply integrating the idea into my conceptual network. This is probably because cloze deletions usually contain lots of extraneous information one can use as “hints.”

Other factors which may be involved:
- [[Spaced repetition memory prompts should encode ideas from multiple angles]], but a cloze deletion just captures one.
- [[Spaced repetition memory prompts should usually focus on one atomic unit]], but cloze deletions are usually narrative prose, which generally isn’t so focused.
- [[Writing one’s own spaced repetition prompts seems to promote understanding]], and writing cloze deletions is much less effortful.
- [[Spaced repetition memory prompts should be concise]], but cloze deletions are usually narrative prose, which includes lots of words that aren’t necessarily relevant to the prompt’s specifics.
- Cloze deletions often have problems with ambiguity, since they use syntactical structure to suggest what they’re asking; see [[Spaced repetition memory prompts should unambiguously produce a specific answer]] and [[Prompts must make clear what “shape” of answer they expect]]
- Naive cloze deletion writing will often produce sentences in which some non-deleted portion of the sentence “gives away” the answer, contra [[Spaced repetition memory prompts should ensure reviewers must retrieve answers from memory]]

An experimental study on this topic; ==to read:==
- Hinze, S. R., & Wiley, J. (2011). Testing the limits of testing effects using completion tests. Memory, 19(3), 290–304.

On the other hand, cloze deletions are an extremely efficient way to produce new prompts, and [[The limiting factor in spaced repetition system capacity is writing enough good prompts]]. If the choice is between cloze prompts and nothing at all, the cloze prompts are definitely better! They’re also more general: [[Cloze deletions can be used to create typical two-sided flashcards]].

Note that these observations are about the impact of cloze deletion prompts on memory. Cloze deletion prompts may work fine for [[Timeful text]] applications like [[The mnemonic medium keeps readers in contact with material over time]]: that’s the theory behind [[Readwise]]’s emphasis on them.

---
# Reference
- Source for this file: [Original article](https://notes.andymatuschak.org/zPJt42JTcoAPTTTa2vdDonV)
2. [[Andy Matuschak/Piotr Wozniak - Effective learning - Twenty rules of formulating knowledge|Piotr Wozniak - Effective learning - Twenty rules of formulating knowledge]] 