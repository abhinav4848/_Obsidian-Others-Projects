# How might the mnemonic medium enable readers in genres outside platform knowledge?
Type of Link: 📝 Article
Author: Andy Matuschak
Completion Status: To Start
Last edited time: January 18, 2024 7:55 PM

## References
- Source for this file: [Original article](https://notes.andymatuschak.org/z6eSdsLVZLGWuR7m3WQGgAY)
