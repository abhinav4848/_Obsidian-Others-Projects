# Spaced everything
Alternative term for [[Programmable attention]] as implemented via spaced-repetition-style systems; see [[Spaced repetition systems can be used to program attention]] for main article.

Related: [[OS-level spaced repetition system]]

## References
- Source for this file: [Original article](https://notes.andymatuschak.org/z9hscgkG2TeqgUtu3vAEW3U)
