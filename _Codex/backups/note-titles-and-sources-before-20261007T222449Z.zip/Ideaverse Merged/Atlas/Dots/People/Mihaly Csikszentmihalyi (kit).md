---
up:
  - "[[Ideaverse Merged/Atlas/Dots/Things/FlowCreation MOC]]"
related:
  - "[[Ideaverse Merged/Atlas/Dots/Things/FlowCreation MOC]]"
created: 2020-06-01
tags:
  - people
dates: 1934 - 2021
in:
  - "[[Ideaverse Merged/Atlas/Maps/People]]"
peopleType:
  - Prominent
peopleDomain:
  - Science & Tech
peopleGroups:
lifespan: 1934 - 2021
finalAge: "87"
culturalEra:
culturalWorks:
  - "[[Ideaverse Merged/Atlas/Dots/Things/Flow]]"
image: https://www.worldgovernmentsummit.org/images/default-source/speakers/2017/mihaly821679c4e97c6578b2f8ff0000a7ddb6.jpg
aliases:
- Mihaly Csikszentmihalyi
---
Mihaly Csikszentmihalyi is the author of [[1990 - Flow]] (not included in Ideaverse for Obsidian). Flow remains one of the most influential books on my thinking.

![[Ideaverse Merged/x/Images/flow-map-original.jpg]]


## Extra
### Wiki
Mihaly Csikszentmihalyi is a Hungarian-American psychologist. He recognized and named the psychological concept of [[Ideaverse Merged/Atlas/Dots/Things/Flow]], a highly focused mental state conducive to productivity. He is the Distinguished Professor of Psychology and Management at Claremont Graduate University.

> Mihaly Csikszentmihalyi (29 September 1934 – 20 October 2021) was a Hungarian-American psychologist. He recognized and named the psychological concept of flow, a highly focused mental state conducive to productivity. 
>
> [Wikipedia](https://en.wikipedia.org/wiki/Mihaly%20Csikszentmihalyi)


