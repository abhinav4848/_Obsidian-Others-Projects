---
up:
  - "[[Ideaverse Merged/Atlas/Maps/Meta PKM]]"
related: []
created: 2020-06-01
tags:
  - x/readme
---
The Evernote Web Clipper thunders towards Gandalf trying to infect and corrupt your PKM sanctuary with hordes of low-value articles you'll never read and that will drown your own thinking a pit of orc-like chaos.

### Choose
- [[Ideaverse Merged/Atlas/Dots/Statements/Be tempted by power and clip countless articles into your PKM note library.]]
- [[Ideaverse Merged/Atlas/Dots/Statements/Ask Gandalf for assistance.]]
