---
in:
  - "[[Ideaverse Merged/Atlas/Maps/Books]]"
related:
  - "[[2021 - The Extended Mind]]"
by:
  - "[[Annie Murphy Paul]]"
publisher: "[[Eamon Dolan Books]]"
published: 2021
created: 2023-10-28
tags:
  - "#source/book"
bookType: NF
bookCategory: Psychology
bookGroup: 
pages: 357
isbn: 0544947665 9780544947665
image: http://books.google.com/books/content?id=Dk-_DwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
year: 2021
yearXP: 2022
yearXPL: 2022
bookStatus: partially read
rating: 5
bookTitle: "[[Ideaverse Merged/Atlas/Dots/Sources/Books/The Extended Mind]]"
bookSubtitle: 
bookPublisher: 
bookEditor: 
bookAgent: 
bookImprint: 
bookImprintEditor: 
bookPraise: 
bookAcknowledged: 
bookDesigner: 
bookIllustrator: 
bookLCSH:
  - Mind and body
  - Thought and thinking
  - Cognition
bookParts: 
bookPartNames: 
bookChapters: 
bookCorePages: 
bookAppendices: 
bookChapterNotes: 
bookBibliography: 
bookIndex: 
bookFont:
---

![cover|150]({{coverUrl}})

# The Extended Mind
![cover|150](http://books.google.com/books/content?id=Dk-_DwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

