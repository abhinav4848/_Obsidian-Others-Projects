---
up:
  - "[[Home]]"
down:
  - "[[Relate]]"
related:
  - "[[Concepts]]"
created: 2023-08-18
in:
  - "[[Maps]]"
---

It's time to give **_"thinking"_** the space it deserves. Let's cultivate this inherently rich endeavor.

My first stop for thinking is to the [[Relate]] where I do what's easy. That means bouncing from note to note, developing them in a special way to maintain [[Ideaverse Merged/Atlas/Dots/Things/Flow]]. I keep the [[Concepts]] handy because I believe a handful of core concepts influence our entire worldview in disproportionately powerful ways. These notes help me make leaps of insights while connecting new ideas to existing concepts.

> [!NOTE]- Some links and content in this note have been removed.
> Because this is a vertical slice of my actual PKM system, I can't include everything in this vault and I left out some notes and material for ease of navigation and understanding the concepts (rather than getting lost in the knowledge) as well as for privacy.
>
> Plus, it's okay to have some unlinked notes in your own vault. They won't all be built out at once.

I'm a big believing in the power of prompts. A couple good prompts is enough to kickstart my thinking. That's why I have so many notes on prompts such as "The NoMa Method", the "7 C's", and even the "11 C's". But for Ideaverse Lite, I'll just point you towards [[Ideaverse Merged/Atlas/Dots/Things/Refraction Thinking]] and [[Ideaverse Merged/Atlas/Dots/Things/Levels of Magnification]].

If you want to solve a problem _and_ gain clarity, a nice concept to brush up on is the [[Ideaverse Merged/Atlas/Dots/Things/OODA Loop]].

Outside the scope of Ideaverse Lite are my joyful suite of mind exercises. I love jumping into the gauntlet of [[Thought Unpacking]] and [[Thought Enriching]]—both of which generate large quantities of [[Ideaverse Merged/Atlas/Dots/Things/Thought Collisions]]. The "unpacking" is best to prompt critical and analytical thinking. The "enriching" is best to exercise the lateral, creative, and metaphorical muscles of the mind.

Want more mind training?

- Go to [[Meditation Jaunts]] and [[Brief Meditation Sequences]] to slow down and reset.
- Go to a few of your [[Mind Palaces]] to work your visualizing muscles.
- Combine the mental with the physical for the world-champion [[Lucia Stance]]
- A few grounding tactics are to brush up the [[Ideaverse Merged/Atlas/Dots/Things/FlowCreation MOC]] and [[Habits Map]]s.

Always remember, one of the best prompting tools out there is the thesaurus. So when you want to both jumpstart and enrich your thinking, grab a thesaurus and go on a [[Word Excursion]].

## Definitions

Let's define some overlapping conceptual categories:

- **Concept**: A concept is a pattern, truth, or mechanism that has been given a name.
- **Mental Models** are specific readily-available patterns or mechanisms that—_when applied to a current situation or thing_—allow for efficient, optimal action. Great for strategic agency and in-the-moment adaptability.
- **Metaphors** are primarily for relating unlike things. Great for creative expression and a means unto itself.
- [[Ideaverse Merged/Atlas/Dots/Things/Refraction Thinking]] is primarily for broadening perspective and deepening understanding. Great for reviewing, planning, empathizing, and meditating.

## Three thinking styles

1. Top-down thinking
2. [[Ideaverse Merged/Atlas/Dots/Things/Bottom-up thinking]]
3. Middle-out thinking

---

It's a travesty to not have a rich inner world. How are you cultivating yours?

> Wander leads to wonder. I wonder, what does wonder lead to?
