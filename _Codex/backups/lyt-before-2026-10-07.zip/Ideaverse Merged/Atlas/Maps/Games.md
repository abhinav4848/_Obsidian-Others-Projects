---
up:
  - "[[Sources]]"
related: []
created: 2022-01-01
---
This note passively looks at the properties of all notes.

If a note has an `in` property that includes a link to `Games`, it will show up below.


> [!Play]+
> ![[Ideaverse Merged/x/Images/flight-school-hotkey-wide.jpg]]