---
up:
  - "[[Ideaverse Merged/Atlas/Notes/Things/FlowCreation MOC]]"
related:
  - "[[Ideaverse Merged/Atlas/Dots/Things/Balancing Challenge and Skill]]"
created: 2020-06-01
---
Attention is what the mind is focused on—and what it has been focused on over the recent past (the past 72 hours is simple way to look at it). Everything that enters the mind in the past 72 hours affects the next hour of thought. That's what it's so important to Guard and Guide Your Mind wisely.

Guard what enters your mind, and what stays in the mind. Reduce distractions. Reduce attentional switching.

### Subsets of Attention
- **Focus** — The ability to maintain focus is of crucial importance in any aspect of modern living. Without focus, life drifts from stimuli to stimuli, with very little consistent [[Ideaverse Merged/Atlas/Notes/Things/Direction (re Flow)]].
- **Residual Attention** — Your *attention* isn't just about what you are thinking about right now; it's more so composed of everything that's entered your mind over past 72 hours.
    - Similar Keywords: Attentional Residue, Echo, Resonating, Ripples, Shadows, Reflections, Glimmers, Whispers, Deja Vu, Attention Robbers, Attentional Switching, Distraction Radiation, Distraction Amnesia, Continuity of Thought

## Main Factors Governing Attention
- Intensity and Frequency of Distractions
    - Surroundings and Environment
- Quality of Diet

### Causes of Poor Attention
- Distractions — Distractions come in many forms and factors. Below is a list of major sources of distraction to safeguard against:
- [[Poor Diet]] (not available in Ideaverse for Obsidian) — Sugar makes people act impulsively; they become more susceptible to distractions. Grains can cause brain fog to lowers mood and Enthusiasm. Both dramatically raise blood sugar levels causing the secretion of Insulin. The resulting fall of blood glucose levels causes hunger, irritability, and energy crashes.
- Average Diet — Even an average diet can still have several micro-nutrient deficiencies that can be the cause of headaches, lower [[Ideaverse Merged/Atlas/Notes/Things/Energy (re Flow)]] levels, mood swings, a lack of enthusiasm.
- Lack of [[Ideaverse Merged/Atlas/Notes/Things/Enthusiasm (re Flow)]]
- Lack of [[Ideaverse Merged/Atlas/Notes/Things/Direction (re Flow)]]

### Solutions to Poor Attention
- Reducing Distractions in Intensity and Frequency
- Having a Good Diet