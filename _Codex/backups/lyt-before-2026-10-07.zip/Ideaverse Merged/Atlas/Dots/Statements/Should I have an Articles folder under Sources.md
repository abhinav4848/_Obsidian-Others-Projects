---
up:
  - "[[Meta PKM]]"
related: []
created: 2020-06-01
---
Why a separate folder for "articles"? This requires a long, complex, and nuanced answer. But I don't have the time to explain it again here, so I'll simple hint that the driving concept behind this is the [[Ideaverse Merged/Atlas/Dots/Things/Signal to Noise Ratio]].

...okay a little more explanation. For millennia, humanity didn't have easy access to quality information. For ≈20 years, humanity has WAAYYY too much access to information. We've been trained to over-collect this information. But we're finding out that this strategy leads to under-thinking and overwhelm. (See: Anywhere I share opinions about this.)

There are healthier strategies to managing the NOISE out there. This is one tiny tactic amidst the broader strategy of better knowledge management.