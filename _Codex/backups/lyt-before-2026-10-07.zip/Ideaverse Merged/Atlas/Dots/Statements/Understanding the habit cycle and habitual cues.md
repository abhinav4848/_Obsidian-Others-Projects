---
up:
  - "[[Habits Map]]"
related: []
created: 2013-03-10
modified: 2020-05-28
---

### The Habit Cycle
Charles Duhigg made popular a three-step process of habit formation. Later, James Clear argued for a fourth step "craving", which I always felt was missing as well. Here's the cycle as I see it:

- **Cue** (Make it Obvious vs Invisible)
- **Craving** (Make it Attractive vs Unattractive) - timing is important
- **Routine** (Make it Easy vs Difficult)
- **Reward** (Make it Satisfying vs Unsatisfying) - Behaviors that are immediately rewarded get repeated. Behaviors that are immediately punished don't get repeated. That's why you need to make it enjoyable in the moment. One way is tying your identity to it. Frame your rewards.

For more, see [[Ideaverse Merged/Atlas/Notes/Ideas/How Atomic Habits fit into the conversation on habits]].

Duhigg calls the most important habits "Keystone Habits". These are the special habits, that by doing, make all the other habits that much easier to accomplish. I've identified my keystone habits, which I'm coining as "resiliency routines" because my mindset has been forever altered by the concept of [[Ideaverse Merged/Atlas/Dots/Things/Antifragility]]. See which [[Ideaverse Merged/Atlas/Notes/Ideas/Resiliency Routines help regain a sense of control]].

### Types of habitual cues
1. Location
2. Time
3. Emotional State
4. Other People
5. Immediately preceding action

Here's an example of me [[Ideaverse Merged/Atlas/Dots/Things/Charting out habit cycles in my life circa 2013]].