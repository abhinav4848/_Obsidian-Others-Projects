---
up:
  - "[[Meta PKM]]"
related: []
created: 2020-06-01
---

For those that want to maintain an alphabetical "Map of Maps" list, check this out. The below list *was* in alphabetical order a long time ago. But as I make sense of the world, I constantly tweak filenames. So now look at how out of order it has become. 

This is why you should just use the tag `#MOC` for your alphabetical list instead.

- [[Meta PKM]]
- [[Greco-Roman MOC]]
- [[Art MOC]]
- [[Confucianism MOC]]
- [[Cooking MOC]]
- [[Cosmology MOC]]
- [[Football MOC]]
- [[History MOC]]
- [[Building Homes MOC]]
- [[Ideaverse Merged/Atlas/Maps/Language MOC]]
	- [[Chinese Language MOC]]
	- [[English Language MOC]]
	- [[French Language MOC]]
	- [[Latin Language MOC]]
- [[Literature MOC]]
- [[Rhetoric MOC]]
- [[Stoicism MOC]]
- [[Philosophy MOC (kit)]]
- [[Vocals MOC]]
- [[Words MOC]]