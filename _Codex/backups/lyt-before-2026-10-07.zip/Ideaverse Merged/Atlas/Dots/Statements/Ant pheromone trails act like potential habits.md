---
up:
  - "[[Habits Map]]"
related:
  - "[[Ideaverse Merged/Atlas/Notes/Ideas/Cobwebs into Cables]]"
created: 2021-01-01
---

*Pheromone trails can become pheromone super-highways.*

Ants produce a mixture of chemicals that they leave behind as they walk, which we then refer to as pheromone trails. These trails lead the ants to food and water sources.

In this way, one ant's pheromone trail is like when we're creating a new habit (whether it's intentional or not). The pheromone trail increases the chance that that very same trail will be walked again. This is how cobwebs can turn into cables over time (see: [[Ideaverse Merged/Atlas/Notes/Ideas/Cobwebs into Cables]]). Or put another way, this is how a pheromone trail can become a pheromone super-highway.