Welcome to Ideaverse for Obsidian. 

LYT stands for **Linking Your Thinking**.

Learn about the 5-week workshop [here](https://www.linkingyourthinking.com/waitlist). Lose less, think better.

»» [Download Ideaverse for Obsidian](https://www.linkingyourthinking.com/myideaverse/start) «« 
%% If you are reading this, you already downloaded it. %%

- Want a sandbox to play in?
- Want a starter kit?

---
### Oh the places you'll go...
But first:

- Do we agree on the [[Ideaverse Merged/Atlas/Notes/Things/Guiding Values of PKM]]?

If we mostly agree, then:

- Go deeper into the [[Ideaverse Map]]...
- Or go [[Home]].