---
up:
  - "[[Ideaverse Merged/Atlas/Notes/Things/LYT Glossary]]"
related:
  - "[[Ideaverse Merged/Atlas/Notes/Things/MOCs (defn)]]"
created: 2020-06-01
---
 *You requested the latest TPS reports?*

Do you ever wish you could save a search? You can. Saved searches are called "queries".

Data view notes are notes with specific sets of queries using the Dataview community plugin. Such as [[Add]]. As you can see, **Data view notes** give you viewports to filter, review, and analyze the information you are accreting. 

> On your idea spaceship, data views are your various viewports.

Armed with a few data views, you can make confident decisions because you know you are getting accurate information.

### What's the difference between MOCs and Data views
While [[Ideaverse Merged/Atlas/Notes/Things/MOCs (defn)]] are for active, generative thinking, the value of data views come from how they *passively* provide you with updated views of information. 

You can analyze or act on that information; but information is worthless without putting meaningful context around it. 

-   Use MOCs to generate insights
-   Use data views to analyze information

Using a series of queries to build data views is an advanced action. But many people want to learn because—in sage hands—queries are crazy-powerful.