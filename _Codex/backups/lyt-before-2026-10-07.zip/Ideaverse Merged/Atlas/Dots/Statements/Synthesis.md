---
up:
  - "[[Concepts Map]]"
in:
  - "[[Concepts]]"
related: 
created: 2020-06-01
rank: 2.5
---
 The combining of separate elements or substances to form a coherent whole.
 
 Related: [[Ideaverse Merged/Atlas/Notes/Things/Convergence (defn)]]

> [!NOTE]- Some links and content in this note have been removed.
> Because this is a vertical slice of my actual PKM system, I can't include everything in this vault and left out some notes and material for ease of navigation and understanding the concepts (rather than getting lost in the knowledge) as well as for privacy. 
>  
> Plus, it's okay to have some unlinked notes in your own vault. They won't all be built out at once.

### Example Usage, Keywords, Concepts, and Metaphors
- Thesis. Antithesis. Synthesis [[201408190641]] - ie Hegelian dialectic [[Ideaverse Merged/Atlas/Dots/Things/MOCs are Dialectics]]
- Chinese culture and Confucianism - Chinese civilization is the longest living because of its ability to synthesize disparate entities, like it's doing currently with Communism and Capitalism.
- The Borg - via assimilation