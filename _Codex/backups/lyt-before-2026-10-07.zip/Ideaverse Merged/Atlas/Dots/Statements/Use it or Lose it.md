---
up:
  - "[[Habits Map]]"
in:
  - "[[Concepts]]"
related: 
created: 2020-06-01
tags:
  - note/develop🍃
rank: 4.5
says: I'll stay or go
---
This is another example of where the [[Ideaverse Merged/Atlas/Notes/Things/Selfish Gene]] is acting. Since [[Ideaverse Merged/Atlas/Notes/Ideas/Habit formation provides an evolutionary advantage]] it's always adjusting to what we are up to. One of the fundamental truism emerges once again:

![[Ideaverse Merged/Atlas/Notes/Ideas/It's circular but true, we become what we do#^f8ca0f]]

### More
In what areas does this apply?

Where does it not apply as much?

Mention strength training for sure. And relate this to spaced repetition.



