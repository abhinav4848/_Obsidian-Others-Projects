---
up:
  - "[[Ideaverse Merged/Atlas/Notes/Ideas/Feedback Loop]]"
related: []
created: 2020-06-01
tags:
  - concept
  - note/develop🍃
---

Growing up, I'd here this around the dinner table. Of course you don't become broccoli if you eat broccoli. 

But you do become shaped by your food in life-altering ways. Everything from our health (obvious), to our disposition (less obvious), and to our gut biome, which likely affects our epigenetics. 

You are what you eat is a more specific comment on one of the fundamental truisms underpinning almost everything:

![[Ideaverse Merged/Atlas/Notes/Ideas/It's circular but true, we become what we do#^f8ca0f]]

I'm really feeling the need to create a new map of content around something I always think about...so here we go: [[Our Tools Shape Us MOC]] (not included in Ideaverse for Obsidian

Related: [[Ideaverse Merged/Atlas/Notes/Ideas/Feedback Loop]]

---
You rest your weary feet by sitting on a nearby stump. As you do, you slow down, and suddenly, you catch a glimmer of something under rock and tree branch. It's an old, smashed scroll clasped in a gold-speckled ribbon. You [[Art of Link Curation|open it]].
