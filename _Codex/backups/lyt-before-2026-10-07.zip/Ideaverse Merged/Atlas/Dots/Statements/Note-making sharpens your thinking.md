---
up:
  - "[[Ideaverse Merged/Atlas/Notes/Ideas/Evergreen notes]]"
related:
  - "[[Ideaverse Merged/Atlas/Notes/Ideas/Note-making creates unexpected optionality]]"
created: 2020-06-01
---

Note-making forces clear, sharp thinking. Here are the basic steps: ^5e4e28c7

- figure out the key statement
- write the note in your own words
- relate the idea in the note to your personal experiences
- link the idea in the note to other ideas

Each aspect isn't a passive process; it's an active, engaged one.

This is profound and not readily apparent. It means that [[Ideaverse Merged/Atlas/Notes/Ideas/Linking your thinking encourages leaps of insights]].