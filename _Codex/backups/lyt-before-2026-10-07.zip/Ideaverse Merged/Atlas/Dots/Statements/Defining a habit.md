---
up:
  - "[[Habits Map]]"
related: []
created: 2020-06-01
---

A habit is a mirror, it gives what you give it—and what you were given is what you'll give. It's the immediate expression a [[Ideaverse Merged/Atlas/Notes/Ideas/Feedback Loop]].

[[Ideaverse Merged/Atlas/Notes/Ideas/Habits carry a ton of hidden inertia]]. To change a habit requires conscious, deliberate effort. 

As you attempt to change a habit, you have to expend effort to reroute the train. [[Ideaverse Merged/Atlas/Notes/Ideas/Changing a habit is really about replacing a routine]].