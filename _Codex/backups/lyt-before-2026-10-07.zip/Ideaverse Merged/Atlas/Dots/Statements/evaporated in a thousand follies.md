---
up:
  - "[[Ideaverse Merged/Atlas/Notes/Ideas/Direction (re Flow)]]"
related: []
created: 2020-06-01
tags:
  - source/quote/100
---

Dantes asks, 

> "What would you not have accomplished if you had been free?” 

The wise Abbe replies, 

> "Possibly nothing at all; *the overflow of my brain would probably, in a state of freedom, have evaporated in a thousand follies.* 
> 
> Captivity brings light to the treasures of the human intellect, just as compression is needed to explode gunpowder. 
> 
> From the collision of clouds electricity is produced; from electricity, lightning; from lightning, illumination." - [[Ideaverse Merged/Atlas/Dots/Sources/The Count of Monte Cristo]]

### My notes
Captivity, compression, collision... concentration, density, tightly-packed

light, spark, explode, electricity, lightning, illumination

> The tightly-packed collision of clouds produces intense electricity in the form of lightning; and from lightning comes illumination. The same is true for ideas. 

I mash up this concept from [[Alexandre Dumas]] with the Large Hadron Collider in Switzerland in my LYT workshop lesson focused on [[Ideaverse Merged/Atlas/Notes/Ideas/Thought Collisions]].

Over at [[Ideaverse Merged/Atlas/Notes/Ideas/MOCs are Dialectics]], we continue marinating in this pressure cooker of thought.
