---
title: "060- Public Note Repositories"
---
# 060- Public Note Repositories
# Public Note Repositories
are collections of peoples personal notes made public. I’m still thinking about the utility of them. On one hand they are a good for showing others a tangible example of how to create a notes collections. My favorite so far is [Andy’s Working Notes](https://notes.andymatuschak.org/About_these_notes) in terms of layout and quality of content.

It is not a particularly desirable way of communicating information to others because they aren’t structured for easy understanding. Instead what you’d want is either a blog (e.g. [Wait But Why](https://waitbutwhy.com/), [Derek Sivers](https://sivers.org/), and [Farnam Street](https://fs.blog/blog/)), site of curated articles (e.g. [thoughtco 10](https://www.thoughtco.com/) or [owlcation 12](https://owlcation.com/)), or small wikis (e.g. [SuperMemo Guru](https://supermemo.guru/wiki/SuperMemo_Guru), [AskHistorians Wiki](https://www.reddit.com/r/AskHistorians/wiki/index)). While these options are better than a standalone notes collection they are still lacking. Specifically they don’t do the best job of addressing the issue of [match quality in learning](https://forum.obsidian.md/t/obsidian-zettelkasten/1999/62).

The direction I am currently leaning is to make a Wiki with an explorable back end that is a [zettelkasten](https://forum.obsidian.md/t/obsidian-zettelkasten/1999/2). The homepage of the website would be a table of contents similar to my [old github one](https://github.com/dogwaddle/CreativeProductivityGuideOld/wiki/Table-of-Contents) which leads to [wiki entries of similar size to supermemo guru](https://supermemo.guru/wiki/Abstract_knowledge). Inside each of the entries are links to the zettelkasten notes that were used to build them. You could also access the zettelkasten through an index, which would be a link in the sites navigation bar.

See [Curated list of Public Zettelkastens / Second Brains / Digital Gardens](https://forum.obsidian.md/t/curated-list-of-public-zettelkastens-second-brains-digital-gardens/968/2)