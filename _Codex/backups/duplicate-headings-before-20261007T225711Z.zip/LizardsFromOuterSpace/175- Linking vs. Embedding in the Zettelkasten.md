---
title: "175- Linking vs. Embedding in the Zettelkasten"
---
# 175- Linking vs. Embedding in the Zettelkasten
# Linking vs. Embedding in the Zettelkasten 
Linking vs. Embedding in the Zettelkasten: what is the criteria one should use on deciding whether to just link to another note or create an embed within the note. This is the distinction between notes being directly and indirectly related. Is the new note part of a larger note sequence?

The process that I’m moving towards now after having thought about it, is to keep all notes on a given topic in a single note because we have the ability to edit notes and infinitely expand on a single note. In a digital system, the only reason to make notes atomic is to promote understanding. If I link to a note that is 2000 words long, then it could be confusing to know what idea I’m referencing specifically. On the flip side it isn’t necessary to atomize to the extent that I have so far. **Where I’m settling down is to let notes naturally grow really long and only excise a paragraph and re-embed it in the document when I want to reference it elsewhere.**