---
title: "080- Attention Abilities"
---
# 080- Attention Abilities
# Attention Abilities
Improving your ability to pay attention helps with knowledge work because it allows you to focus for a longer period of time. Which is necessary for the deep work that is most valuable. One way to improve your attention is through memorizing a deck of cards using a memory palace technique [(Newport 2016, pg 97)](https://forum.obsidian.md/t/obsidian-zettelkasten/1999/10). This comes from the study of memory champions and looking into if they have improved memory over the average person. Turns out that they do not and a large part of their success comes down to their superb attention abilities.