---
title: "207- Luhmann on Possibility of Linking"
---
# 207- Luhmann on Possibility of Linking
# **Luhmann on Possibility of Linking**
Luhmann describes how a number sequence allows for linking between notes

> **2. Possibility of linking ( _Verweisungsmöglichkeiten_ ).** Since all papers have fixed numbers, you can add as many references to them as you may want. **Central concepts can have many links which show on which other contexts we can find materials relevant for them**. Through references, we can, without too work or paper, solve the problem of **multiple storage**. Given this technique, it is less important where we place a new note. If there are several possibilities, we can solve the problem as we wish and just record the connection by a link (or reference). Often the context in which we are working suggests a multiplicity of links to other notes. This is especially the case when the card index is already voluminous. In such cases it is important to capture the connections radially, as it were, but at the same time also by right away recording back links in the slips that are being linked to. In this working procedure, the content that we take note of is usually also enriched

**Source -** [Communicating with Slip Boxes: An Empirical Account - essay by Niklas Luhmann](http://luhmann.surge.sh/communicating-with-slip-boxes)