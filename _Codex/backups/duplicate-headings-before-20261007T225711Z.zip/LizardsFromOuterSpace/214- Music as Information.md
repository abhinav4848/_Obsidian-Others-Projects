---
title: "214- Music as Information"
---
# 214- Music as Information
# Music as Information
In the book _How Music Works_, author David Byrne discusses how much of music throughout history was intensely shaped by the environment it existed in. This is in contrast to how people often perceive music as being spontaneously generated from the musician’s inner soul. Simply put, the reason medieval church music sounds the way it does, is due to the fact that other types of popular music sound like crap in a big cathedral. No one wants to hear crappy music.

This can be related to my discussion ([[028- Mediums of Information Management]]) on how note taking has evolved over the years based on the mediums. Something I haven’t though about enough, which the above book made me realize, is how the different mediums of information management have shaped the ways we take notes. It is part of the storage process ([[053- Storing]].

When you take notes in a more atomic, decontextualized, and individual manner, does that change how you think? Do you start automatically thinking in such a way as you are reading and writing?