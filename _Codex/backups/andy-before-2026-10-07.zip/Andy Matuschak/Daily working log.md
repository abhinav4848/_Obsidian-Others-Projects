# Daily working log
Each day, I start a note titled with that day’s date; e.g. 2020-03-12. It captures ephemera throughout the day: reflections, scratch work, etc. It’s an intentional dumping ground, a release valve so that there’s always “a place to put that thing.”

In the [[Taxonomy of note types]], this is the lowest-fidelity layer, ephemeral by design. But as scratch thoughts look like they might have legs, they get extracted into a note in my writing inbox ([[A writing inbox for transient and incomplete notes]]). Sometimes I’ll use the daily working log as a drafting space, and I can extract sections roughly-as-is into [[Andy Matuschak/Evergreen Notes|Evergreen Notes]].

For me, the important bits are:
1. This is a space where I can put anything and feel zero friction. ([[Close open loops]])
2. I feel a natural pressure to extract anything which wants to “outlive the day”—to move up the  [[Taxonomy of note types]]. 

Because the daily working log is also a live note, it also functions as a useful stub for:
[[Contextual backlinks]] [[Backlinks can be used to implicitly define nodes in knowledge management systems]]. 
# Reference
1. [Andy Link](https://notes.andymatuschak.org/About_these_notes?stackedNotes=z5E5QawiXCMbtNtupvxeoEX&stackedNotes=zKGjQtsTKgscAoq271ZzKqw&stackedNotes=zTn3g4wTm1hbkNFUvLLjpev&stackedNotes=zR6RRbCfY5rFkiimFnaJZKB&stackedNotes=z4EXkuLjdBrBZe7PVAGXc5a&stackedNotes=zNUaiGAXp21eorsER1Jm9yU&stackedNotes=zDh1yhNFQNxDEre12B4zd8k&stackedNotes=zLhoRUyjKU665EY16u4XXJy&stackedNotes=zTDjZQbKAT9pALtsk2HfePx&stackedNotes=zXRs9fj5BuX5FmrQzPxqWUs)