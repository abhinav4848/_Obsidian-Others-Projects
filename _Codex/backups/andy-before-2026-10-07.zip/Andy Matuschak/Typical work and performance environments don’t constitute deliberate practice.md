# Typical work and performance environments don’t constitute deliberate practice
Effective [[Andy Matuschak/Deliberate practice|Deliberate Practice]] offers students opportunities for focused repetitions. During a baseball game, a batter may only swing a dozen times, but a batter working with an expert coach may attempt hundreds of pitches a day. Even better: those pitches may all be designed to exploit a specific weakness (Ericsson et al, 1993, p. 368).

Because [[Skill development requires challenging homeostasis]], failure must be common during deliberate practice. But typical work and performance environments rarely tolerate high rates of failure. A pianist can’t practice his fingerings by scheduling more recitals: he’ll quickly be kicked off the touring circuit.

One point of partial disagreement discussed in [[Deliberate practice doesn’t have to be unenjoyable]].

---

## References
1. [Andy Link](https://notes.andymatuschak.org/z5Rvwe2Wo2UvxHxLujUWnsa)
2. Ericsson, K. A., Krampe, R. T., & Tesch-Römer, C. (1993). The role of deliberate practice in the acquisition of expert performance. _Psychological Review_, _100_(3), 363. [Ericsson, K. A., Krampe, R. T., & Tesch-Römer, C. (1993). The role of deliberate practice in the acquisition of expert performance. Psychological Review, 100(3), 363](https://notes.andymatuschak.org/zEkCRJXM9NYCXxzFoDaNhL)
3. [2022-03-31 Patreon update - Implicit practice - a sight reading parable](https://notes.andymatuschak.org/zkjewjoFaCcm5VuFM1Enb9)