---
URLs:
  - https://notes.andymatuschak.org/z4dnHytTo3WGoqbHfVb4YRn
---
# Recast celebrations as reflective spaces, rather than rewards
I’ve worked hard to cultivate [[Process over product]]. That stance still feels delicate, perhaps a little brittle. My natural emotional response pattern is to fixate on outputs and achievements; it feels like I have to carefully shepherd my mental states away from that. In this context, what to do when I’ve just finished a big project or received a big grant? Celebration feels “dangerous”: it’s so much louder and more visceral, emotionally, than the subtle enjoyment in day-to-day creative work.

I’m apprehensive that if I celebrate with a big party or a fancy dinner or by buying myself some gadget I’ve been wanting, I’ll undo some of my “process over product” emotional work. And yet it also seems bad to never celebrate important moments of success: that feels like a kind of dissociation. Or at least, it’s leaving some meaningful aliveness unfelt.

For my most recent celebration, I spent a long time reflecting on what would feel right, and I came away with this thesis: rather than thinking about celebration as _exciting reward_, I want to think about it as creating a space to _savor, linger, or relish_ the feelings up to and around that success. If a normal celebration is analogous to a big ice cream sundae, I want something more like a tea ceremony. Subtle, tranquil; about feeling more fully, rather than about hedons.

For this first celebration, Sara and I went to Tunnel Top Park—hadn’t been before—with a blanket and some unfancy rosé. We sat down in view of the Golden Gate Bridge. I brought myself fully into the present as I might do for meditation. Then I opened myself up to the feelings of satisfaction I had about this achievement, about the time leading up to it, and about what it implies for the future. It was lovely to linger in this place: I was able to notice and appreciate a sense of satisfaction from many unexpected angles.

For instance, I noticed that last time I’d reached a point like this, I felt quite apprehensive about a particular category of next step; and this time, when the next step was in the same category, I didn’t. I noticed quiet feelings, like a slowly growing sense of safety or stability around this work.

But I didn’t feel hyper-stimulated. This didn’t feel like something I’d be grasping toward. If obstacles arise between me and some success, I don’t expect I’d flinch away because I’d been using a celebration like this as my carrot.

# References
1. [Andy Link](https://notes.andymatuschak.org/z4dnHytTo3WGoqbHfVb4YRn)