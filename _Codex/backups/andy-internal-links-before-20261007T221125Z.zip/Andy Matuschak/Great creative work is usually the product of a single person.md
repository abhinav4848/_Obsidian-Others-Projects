---
URL: https://notes.andymatuschak.org/z7vdiuQK7HuFyi4V5EemF3e?stackedNotes=zHSk5HpDyrSWCMN669Sg4HU&stackedNotes=zGm1rhtS9vQytd8WNb9TV1
---
Whether in music (Bach, Lennon), art (Picasso, Bernini), film (Tarantino, Anderson), games (Blow, Lantz), fiction (Kundera, Tolstoy), the most eminent work is usually the result of a single person’s creative efforts. Occasionally it’s a very small group (Eames, Wrights).

Why is this?
- Consensus networks quell radical ideas
- [[It’s hard to hear yourself think]] 

This observation creates challenges for [Tools for thought](https://notes.andymatuschak.org/z88M2wwQ8FggV7p8Wu1b8LG) because [[Great tool-makers are often not great tool-users, and vice-versa]]; see [Deep collaborations between tool-makers and tool-users may support insight through making](https://notes.andymatuschak.org/zG1S2XhBhJa7PWeSkKna2Y2).

---

## References
Pendleton-Jullian, A. M., & Brown, J. S. (2018). _Design Unbound_ (Vol. 1–2). MIT Press. [Pendleton-Jullian and Brown, Design Unbound](https://notes.andymatuschak.org/zEA174Nv3BkNkLeuoXerb9u)
> Most truly great works are the result of one person, either acting alone in their studio, or as creative leaders capable of transferring their vision to others. Consider the works of Dante, Cervantes, Joyce; Bach, Wagner, Cage… Most great works have come from one creative mind.
p. 133
