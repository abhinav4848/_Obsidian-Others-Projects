# Learning requires metacognition
To successfully learn something new, people must evaluate their understanding, monitor for confusion or inconsistency, plan what to do next based on those observations, and coordinate that plan’s execution. This often falls under the category of “metacognition,” though [Metacognition is too imprecise a category: prefer to unbundle its phenomena](https://notes.andymatuschak.org/z3CJCzuKJw53tiQAP1zgsEs). (Not Linking as very vague text on Andy’s site)

In a classroom or professional setting, an expert might perform some of these tasks for a learner ([[Metacognitive supports as cognitive scaffolding]]), but when a learner’s on their own, these metacognitive activities may be taxing or beyond reach. Unfortunately, [[Most explanatory media make participants run their own feedback loop]] 

# References

1.