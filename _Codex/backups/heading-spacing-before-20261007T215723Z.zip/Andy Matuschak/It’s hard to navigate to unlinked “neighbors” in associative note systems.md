---
URL: https://notes.andymatuschak.org/%C2%A7Note-writing_systems?stackedNotes=zsRuFxYgckGS81tr2eiBAP&stackedNotes=zPpqLzE6VWKxXF6BpsAfr4C
---
# It’s hard to navigate to unlinked “neighbors” in associative note systems

[[Evergreen notes should be densely linked]], and if you follow the advice in [[Prefer associative ontologies to hierarchical taxonomies]], you’ll find it’s easy to navigate along trails of related ideas. But if several notes are related topically, or related _through_ another note, it’s difficult to navigate between them by the in-note links.

One example: if you have many small notes about techniques for solving problems in cloud systems, it may be helpful to see those “neighbor” notes when viewing a particular note. They’re not directly related, so it doesn’t make sense for them all to link to each other. You could make a “hub” note called “Solving problems in cloud systems” which contains links to all those notes, but you still wouldn’t be able to see those neighbors _from_ a given note. You lose the [[Peripheral vision]] of the backlinks section—you’d have to navigate to the “hub” note first.

Two solutions:
- “Outline notes” can create pseudo-hierarchies with order and structure by linking to many child notes. Then we need the UI to support navigating between neighbors “through” these outline notes.
- Tags (especially hierarchical tags) can help, but they lack authored order and structure: [[Tags are an ineffective association structure]].

---

# References
2. [Luka Dover - Quantum Country interview - 2019-11-19](https://notes.andymatuschak.org/z7yd2pijFR2BRL7d1mqe3d1)