# Flow Stoppers

Find which inhibitor (or two) is currently in the worst shape for you. It is likely a completely different one than it was two hours ago. That's normal because we're constantly living, acting, and reacting to Life.

### Attention
**Distractions** — Lack of focus, which is a part of the element of Attention. Might be from the environment, the surroundings, and/or the digital landscape as well.
**Cognitive Switching** — This can lead to Confusion, Increased Distractibility, Lack of Focus, and Low Motivation. 

### Direction
**Confusion** — Lack of Direction.

### Energy
**Low Energy** — This can lead to Lack of Focus (Increased Distractibility) and Low Motivation
**Decision Overload** — Making too many decisions encourages to mental fatigue

### Enthusiasm
**Low Motivation**
**Low Self-Worth** — This covers any self-esteem issue: self-critiquing, the feeling of "not good enough," worrying too much, feeling ashamed, feeling anxious and overwhelmed.

Now that we've seen the main Flow Stoppers, let's check out the main [[Workflows/03 IMF_AdvancedStarterKit_v2/Solutions to Flow Stoppers]].

---

toc: [[FlowCreation TOC]]
