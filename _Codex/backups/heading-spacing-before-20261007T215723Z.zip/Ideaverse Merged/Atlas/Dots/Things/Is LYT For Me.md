---
up:
  - "[[Ideaverse Merged/Ideaverse Map]]"
related: []
created: 2020-06-01
---

_Disclaimer_: If you are completely new, ignore most of Ideaverse Lite and just start making notes. Come back after you have at least 100 notes.

**If you're just starting out**
You don't _need_ any of this. Just make notes and start writing. Worry about structure later.

**If you've got around 100-500 notes**
Some of your favorite notes will become harder to find. You'll start to desire a way to structure and organize your notes. _Like a vampire thirsting for blood, you'll find yourself gravitating toward the creation of MOCs._

**If you've got around 1000-5000 notes**
You'll want to structure your structures. This is where these flexible frameworks starts providing mega-value. There are a lot of [[Ideaverse Merged/Atlas/Dots/Things/Benefits of LYT frameworks|benefits]].

**If you've got 5000-50,000 notes**
Note retrieval issues become amplified: can you find the thing you're looking for? I would say your only hope is a fundamentally robust set of co-existing frameworks. Hopefully a library with LYT frameworks can scale effectively at these numbers. You'll probably have MOCs built upon other MOCs. I would imagine the Home note (along with search) would be your initial launching pad.

---

## If you have Asperger's, or ADHD, or you just tend to over-organize

I implore you to approach Ideaverse Lite with caution. Sure, it's awesome, but you can't leap to "11" and bypass counting "1, 2, 3, 4, 5, 6, 7, 8, 9, 10". The only structure that can work over time, is the structure that slowly emerges over time—validating its own existence through its use.

This kit shows you how to get there, but DO NOT start structuring your "ultimate" system right now. It will fail you, because it will be fragile, because it wasn't forged in the fire of practical usage. You will waste time and enthusiasm—and could possibly burn out.

> Let the links do the work.

So [[Ideaverse Merged/Atlas/Dots/Things/Trust the process (kit)]] and enjoy the incremental journey of structure emerging organically. As you run into [[Ideaverse Merged/Atlas/Dots/Things/Mental Squeeze Point|Mental Squeeze Points]] keep these principles in mind. Keep them handy. But try to stop yourself from over-designing everything today. It won't be helpful. If that's not enough of a warning, please review [[Ideaverse Merged/Atlas/Dots/Things/Gall's Law]].

---

If you're still enthusiastic about the fluid frameworks in the LYT method, then [[Ideaverse Merged/Atlas/Dots/Things/Set Up Your Home Note]].
