---
up:
  - "[[Ideaverse Merged/Home]]"
related: 
created: 2020-01-01
in:
  - "[[Ideaverse Merged/Atlas/Maps/Maps]]"
updates: By taking the text out of the callouts, we are encouraging you to actually edit the Library note to make it your own
---

Navigate your library of maps with a classification system made specifically for PKM. 

> [!Blocks]- The LYT Classification System
> The **LYT Classification System** is lightly modified from the Cutter, Dewey, and Universal Decimal classification systems used in libraries around the world. It will provide you a time-tested foundation as you structure the interests of your digital library.
> - 000 - *Knowledge Management*
> - 100  - *Personal Management*
> - 200 - *Philosophy & Psychology; Spirituality & Religion*
> - 300 - *Social Sciences*
> - 400 - *Communications & Rhetoric; Language & Linguistics*
> - 500 - *Natural Sciences*
> - 600 - *Applied Sciences*
> - 700 - *Art & Recreation*
> - 800 - *Literature*
> - 900 - *History & Biography & Geography*
> 
> ![[Ideaverse Merged/x/Images/whelan-space-station-1978-mod.jpg]]
> 
> The LYT Classification System is ready-made to hold your diverse interests. 
> 
> Add some placeholders below. 

> [!NOTE]+ ### 000 - Knowledge Management

The [[Ideaverse Merged/Atlas/Maps/Meta PKM]] shows the best practices of knowledge management. I use the [[Ideaverse Merged/Ideaverse Map]] to show the power of linked thinking and to empower others to develop their thinking. The [[Mapping MOCs]] is my personal note to wrap my head around the wondrous beauty that MOCs offer. Others include:

- [[Ideaverse Merged/Atlas/Maps/Relate]] | [[Ideaverse Merged/Calendar/Logs/Logs (Example)]] |  [[I want to...]]
- [[All the Maps]] | [[Ideaverse Merged/Atlas/Dots/Things/Commonplace Book]] |  [[Knowledge and memory MOC]]

> [!Milestone]+ ### 100 - Personal Management

The [[Ideaverse Merged/Atlas/Maps/Thinking Map]] can galvanize my attention; the [[Ideaverse Merged/Atlas/Maps/Concepts]] can flavor it; and the [[Ideaverse Merged/Atlas/Maps/Habits Map]] speaks about how to direct it. Hidden within in the [[Ideaverse Merged/Atlas/Dots/Things/Cabin]]. Go to my [[Ideaverse Merged/Atlas/Maps/Life Map]] to brush up on [[Ideaverse Merged/Atlas/Maps/My Virtues (starter)|My Virtues]] and more.

- [[Posture MOC]] | [[Hormesis MOC]] | [[Breathing Exercises MOC]] | Flowcreation MOC
- People MOC | Family MOC | [[Prominent People (kit)]]
- Efforts MOC | [[Life Command ⌘]] | Plans and Reviews
- Finances MOC | Health MOC

> [!Puzzle]+ ### 200 - Philosophy, Psychology ; Spirituality, Religion

Is there no limit to this section? I use [[Ideaverse Merged/Atlas/Maps/Philosophy MOC (kit)]] as the big note and then point to things like: [[Stoicism MOC]], [[Confucianism MOC]], [[Religion MOC]], [[Taoism MOC]], and whatever else comes up.

[[Ideaverse Merged/Atlas/Maps/Psychology MOC (kit)]] is similar but different enough to have its own space.

> [!User]+ ### 300 - Social Sciences

*The study of human society and of individual relationships in and to society.*
While this a very important section, I have found it's a bit more intimate, as strange as that sounds, so I'm hesitant to share too much here. The best place to start is the [[Ideaverse Merged/Atlas/Maps/People Map]]. along with.

See also: [[Ideaverse Merged/Atlas/Maps/People Map#Prominent People 🌋|Prominent People 🌋]] | Politics | Society | Law | Relationships

> [!Keaton]+ ### 400 - Communications, Language, & Linguistics

A fun section of the library, the 400s contains the underrated and oft-maligned subject of [[Rhetoric MOC]]. And one cannot talk long about rhetoric without talking about [[Ideaverse Merged/Atlas/Maps/Language MOC]], [[Words MOC]], and especially [[Figures MOC]]. Not too far behind is the [[Leadership MOC]].

> [!Trees]+ ### 500 - Natural Sciences

> A sharp break from the previous section, the 500s explore the natural world and universe in glorious notes like [[Cosmology MOC]] and [[Math MOC]]. 
> 
> See also: Chemistry | Geology | Plants | Animals | [[Ideaverse Merged/Atlas/Maps/Systems MOC (kit)]]

> [!Sailboat]+ ### 600 - Applied Sciences

A natural progression from the previous section, this is where we take the the fundamentals of nature and *apply* them. My undergrad was in [[Engineering MOC]], which relates to my interest in [[Building Homes MOC]]. Later on, I developed the [[Editing Manual MOC]].

See also: Agriculture | Technology | Medical | [[AI MOC]] | Programming | [[Collective Intelligence MOC]] | [[Genetics MOC]] | 

> [!Play]+ ### 700 - Art & Recreation
> Ah the leisures of life. Remember leisure? Few really do. This section could easily balloon. 
> 
> - Art MOC | [[Design MOC]] | Architecture | Painting | 
> - Film & TV | [[Ideaverse Merged/Atlas/Maps/Movies]] 
> - Sports | [[Football MOC]] 
> - Music | [[Jazz MOC]] | [[Vocals MOC]] 
> - [[Cooking MOC]] | Leisure 

> [!Venetian]+ ### 800 - Literature

If folks barely remember leisure, they likely completely forgot about classical literature. A great shame, neomania...we blind ourselves to some of humanity's greatest hits. Use [[Literature MOC]] as a launchpad.

> [!Fingerprint]+ ### 900 - History & Biography & Geography

I've noticed I'm naturally building up the [[Ancient Greece MOC]], but I haven't cared to build out the [[History MOC]] just yet. The [[Ideaverse Merged/Atlas/Maps/Places MOC]] is a peculiarly powerful note that has big things in store for it.

The [[Art & Science Storytelling MOC]] look at some great storytellers of history. 

---

Please don't go crazy numbering things. We are just using a pre-made map so we can easily add dots of new interests. 

> [!NOTE]- Some links and content in this note have been removed.
> Because this is a vertical slice of my actual PKM system, I can't include everything in this vault and I left out some notes and material for ease of navigation and understanding the concepts (rather than getting lost in the knowledge) as well as for privacy. 
>  
> Plus, it's okay to have some unlinked notes in your own vault. They won't all be built out at once.

Up to [[Ideaverse Merged/Home]]
